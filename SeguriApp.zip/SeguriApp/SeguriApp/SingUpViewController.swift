//
//  SingUpViewController.swift
//  SeguriApp
//
//  Created by Macbook on 5/7/19.
//  Copyright © 2019 JDGE. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class SingUpViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var user: UITextField!
    @IBOutlet weak var passwork: UITextField!
    @IBOutlet weak var email: UITextField!
    
  
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    @IBAction func crearUser(_ sender: UIButton) {
        
        guard let userEmail = email.text, userEmail != "", let userPass = passwork.text, userPass != "" else{
            return
        }
        Auth.auth().createUser(withEmail: userEmail, password: userPass){ (user, error) in
            
            if let error = error{
                print(error.localizedDescription)
                return
        }
        self.dismiss(animated: true, completion: nil)
    }
        
}

}
