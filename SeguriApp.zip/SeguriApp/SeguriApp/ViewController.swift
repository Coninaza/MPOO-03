//
//  ViewController.swift
//  SeguriApp
//
//  Created by Macbook on 5/7/19.
//  Copyright © 2019 JDGE. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class ViewController: UIViewController {
    @IBOutlet weak var iniciar: UIButton!
    
    @IBOutlet weak var crear: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
                }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        

    }
    @IBAction func reversa( sender: UIStoryboardSegue){}
    @IBAction func regresa( sender: UIStoryboardSegue){}
    }

    



